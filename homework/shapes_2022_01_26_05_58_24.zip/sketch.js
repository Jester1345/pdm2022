function setup() {
  createCanvas(590, 400);
}

function draw() {
  background(0, 255, 100);
  rect(300, 80, 250, 250);
  circle(150,200,250)
}